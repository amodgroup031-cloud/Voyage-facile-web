/* =====================================================================
   VOYAGE FACILE — Espace agence (dans l'application)
   Connexion Supabase : seuls les comptes activés (table "agents")
   voient et modifient les demandes. Le prix affiché au client et les
   passagers ne peuvent pas être modifiés (protégé par la base).
   ===================================================================== */
(function(){
  const sb = window.supabase.createClient(C.SUPABASE_URL, C.SUPABASE_ANON_KEY, { auth: { persistSession: true, storageKey: 'vf-agence' } });
  const LIBA = { nouvelle:'Nouvelle', en_cours:'En cours', confirmee:'Prix confirmé', billet_envoye:'Billet envoyé', annulee:'Annulée' };
  const pill = s => `<span class="pill st-${s}">${LIBA[s]||s}</span>`;
  let DEM = [], filtre = 'actives', ecran = null, timer = null;

  function voir(id){
    ['fLogin','agWait','agDem','agDetail','agReg'].forEach(x => $('#'+x).hidden = x !== id);
    ecran = id; $('#main').scrollTop = 0;
    entete(id === 'agDetail' ? 'Demande' : id === 'agReg' ? 'Réglages' : 'Espace agence');
  }

  async function ouvrirAgence(){
    const { data:{ session } } = await sb.auth.getSession();
    if (!session) { voir('fLogin'); return; }
    const { data: ag } = await sb.from('agents').select('user_id').eq('user_id', session.user.id).maybeSingle();
    if (!ag) { attente(session.user.id); return; }
    voir('agDem'); await charger();
    clearInterval(timer); timer = setInterval(() => { if (NAV.vue === 'agence' && ecran === 'agDem') charger(); }, 30000);
  }
  function retour(){
    if (ecran === 'agDetail' || ecran === 'agReg') { voir('agDem'); return true; }
    clearInterval(timer); return false;
  }

  // Connexion administrateur : e-mail de l'agence + mot de passe
  if (!$('#em').value) $('#em').value = C.AGENCE_EMAIL || '';
  $('#pwVoir').onclick = () => { const v = $('#pw').type === 'password'; $('#pw').type = v ? 'text' : 'password'; $('#pwVoir').textContent = v ? 'Cacher' : 'Voir'; };
  const erreurLogin = m => { $('#eLogin').textContent = m; $('#eLogin').hidden = false; };
  const traduire = msg => {
    const m = String(msg || '');
    if (/invalid login credentials/i.test(m)) return 'E-mail ou mot de passe incorrect.';
    if (/email not confirmed/i.test(m)) return "Compte pas encore prêt. Réessayez dans une minute.";
    if (/rate limit|too many/i.test(m)) return 'Trop de tentatives. Patientez quelques minutes puis réessayez.';
    if (/network|fetch/i.test(m)) return 'Pas de connexion Internet. Vérifiez votre réseau.';
    return 'Connexion impossible : ' + m;
  };
  function attente(uid){ $('#uid').textContent = uid || '—'; voir('agWait'); }

  // Comme GUINEE TOURS : le compte administrateur est créé par le serveur à partir du mot de passe
  // enregistré par l'agence (secret VF_ADMIN_PASSWORD). Ici, on se connecte simplement.
  async function demanderServeur(){
    try {
      const r = await fetch(C.SUPABASE_URL + '/functions/v1/vf-api', { method:'POST',
        headers:{ 'Content-Type':'application/json', 'apikey':C.SUPABASE_ANON_KEY, 'Authorization':'Bearer ' + C.SUPABASE_ANON_KEY },
        body: JSON.stringify({ action:'admin' }) });
      return r.ok ? await r.json() : null;
    } catch(e){ return null; }
  }
  async function connexion(email, password){
    let { error } = await sb.auth.signInWithPassword({ email, password });
    if (error && /invalid login credentials/i.test(error.message) && email === String(C.AGENCE_EMAIL || '').toLowerCase()) {
      const s = await demanderServeur();                 // le serveur vérifie que le compte suit bien le mot de passe enregistré
      if (s && s.pret === false) return erreurLogin("L'espace agence n'est pas encore configuré : le mot de passe administrateur doit d'abord être enregistré sur le serveur.");
      if (s && s.change) ({ error } = await sb.auth.signInWithPassword({ email, password }));
    }
    if (error) return erreurLogin(traduire(error.message));
    $('#pw').value = ''; $('#pw').type = 'password'; $('#pwVoir').textContent = 'Voir'; ouvrirAgence();
  }

  $('#fLogin').addEventListener('submit', async e => {
    e.preventDefault(); $('#eLogin').hidden = true;
    const email = $('#em').value.trim().toLowerCase(), password = $('#pw').value;
    if (!/^[^\s@]+@[^\s@]+\.[a-z]{2,}$/i.test(email)) return erreurLogin("Indiquez l'adresse e-mail de l'agence.");
    if (!password) return erreurLogin('Indiquez le mot de passe administrateur.');
    const bt = $('#bLogin'); bt.disabled = true; bt.textContent = 'Connexion…';
    try { await connexion(email, password); }
    catch (er) { erreurLogin(traduire(er && er.message)); }
    finally { bt.disabled = false; bt.textContent = 'Se connecter'; }
  });
  $('#bRetry').onclick = () => ouvrirAgence();
  const sortir = async () => { clearInterval(timer); await sb.auth.signOut(); voir('fLogin'); };
  $('#bOut1').onclick = sortir; $('#bOut2').onclick = sortir;

  async function charger(){
    const { data, error } = await sb.from('demandes').select('*').order('cree', { ascending:false }).limit(300);
    if (error) { toast('Chargement impossible'); return; }
    const avant = new Set(DEM.filter(d => d.statut === 'nouvelle').map(d => d.id));
    const premier = DEM.length === 0;
    DEM = data || [];
    if (!premier && DEM.some(d => d.statut === 'nouvelle' && !avant.has(d.id))) toast('Nouvelle demande reçue');
    afficher();
  }
  function afficher(){
    const mois = new Date().toISOString().slice(0,7);
    $('#kNew').textContent = DEM.filter(d => d.statut === 'nouvelle').length;
    $('#kCours').textContent = DEM.filter(d => d.statut === 'en_cours' || d.statut === 'confirmee').length;
    const env = DEM.filter(d => d.statut === 'billet_envoye' && (d.maj||'').slice(0,7) === mois);
    $('#kEnv').textContent = env.length;
    $('#kCom').textContent = gnf(env.reduce((s,d) => s + (d.prix_final_gnf != null ? Math.max(0, d.prix_final_gnf - (d.prix_indicatif_gnf - d.commission_gnf)) : d.commission_gnf), 0));
    const l = DEM.filter(d => filtre === 'toutes' || (filtre === 'actives' ? ['nouvelle','en_cours','confirmee'].includes(d.statut) : d.statut === filtre));
    $('#agList').innerHTML = l.length ? l.map(d => `<button class="card" type="button" data-id="${esc(d.id)}" style="text-align:left;width:100%">
       <div class="top"><div><b>${esc(d.id)}</b> · ${esc(d.trajet)}</div>${pill(d.statut)}</div>
       <div class="muted">${esc(d.passagers.map(p => p.prenom + ' ' + p.nom).join(', '))}</div>
       <div class="row2"><span class="muted">${esc(new Date(d.cree).toLocaleString('fr-FR',{day:'2-digit',month:'2-digit',hour:'2-digit',minute:'2-digit'}))}${d.notif_ok ? '' : ' · alerte WhatsApp non partie'}</span><b>${gnf(d.prix_final_gnf ?? d.prix_indicatif_gnf)}</b></div></button>`).join('')
      : '<div class="panel muted">Aucune demande ici pour l\'instant.</div>';
    $('#agList').querySelectorAll('[data-id]').forEach(b => b.onclick = () => detail(b.dataset.id));
  }
  document.querySelectorAll('#filters button').forEach(b => b.onclick = () => { filtre = b.dataset.f; document.querySelectorAll('#filters button').forEach(x => x.setAttribute('aria-pressed', x === b)); afficher(); });

  const dj = iso => { const d = new Date((iso||'').slice(0,10)+'T12:00:00'); return isNaN(d) ? '' : d.toLocaleDateString('fr-FR',{weekday:'short',day:'numeric',month:'short',year:'numeric'}); };
  const hm = iso => (iso||'').slice(11,16);
  const leg = (t, titre) => !t ? '' : `<div><b>${titre}</b> · ${esc(dj(t.depart_heure))}<br>${esc(hm(t.depart_heure))} ${esc(t.depart_aeroport)} → ${esc(hm(t.arrivee_heure))} ${esc(t.arrivee_aeroport)}<br>${esc(t.vols.join(' + '))} · ${t.escales ? t.escales + ' escale(s) ' + esc(t.escales_aeroports.join(', ')) : 'direct'}<br><span class="muted">${esc(t.compagnie)}</span></div>`;
  const waClient = (tel, texte) => 'https://wa.me/' + String(tel).replace(/\D/g,'') + '?text=' + encodeURIComponent(texte);

  function detail(id){
    const d = DEM.find(x => x.id === id); if (!d) return;
    const o = d.offre;
    const paxTxt = d.passagers.map((p,k) => `${k+1}. ${({ m:'M. ', f:'Mme ', mlle:'Mlle ' }[p.civilite] || '')}${p.nom} ${p.prenom}${p.naissance ? ' (né(e) le ' + p.naissance + ')' : ''}`).join('\n');
    $('#agDetail').innerHTML = `
      <h2>${esc(d.id)} · ${esc(d.trajet)}</h2>
      <div class="box">${leg(o.aller,'Aller')}${o.retour ? '<hr style="border:0;border-top:1px solid #d5e1ef;margin:8px 0">' + leg(o.retour,'Retour') : ''}</div>
      <div class="box"><b>Passagers</b><div style="white-space:pre-wrap;margin:4px 0 8px">${esc(paxTxt)}</div><button class="btn btn-ghost w100" type="button" id="cpPax">Copier les passagers</button></div>
      <div class="box"><div class="row2"><span>Client</span><b>${esc(d.telephone)}</b></div>${d.email ? `<div class="row2"><span>E-mail</span><span>${esc(d.email)}</span></div>` : ''}${d.message_client ? `<div style="margin-top:6px">Message : ${esc(d.message_client)}</div>` : ''}</div>
      <div class="box"><div class="row2"><span>Prix affiché</span><b>${gnf(d.prix_indicatif_gnf)}</b></div>${d.devise_client && d.devise_client !== 'GNF' && d.prix_client ? `<div class="row2"><span>Vu par le client</span><span>${esc(Number(d.prix_client).toLocaleString('fr-FR').replace(/[\u00a0\u202f]/g,' ') + ' ' + d.devise_client)}</span></div>` : ''}<div class="row2"><span>dont commission</span><span>${gnf(d.commission_gnf)}</span></div><div class="row2"><span>Prix trouvé</span><span>${o.prix_source ? esc(o.prix_source.montant + ' ' + o.prix_source.devise) : '—'}</span></div></div>
      <div class="box" id="dfBox">${boiteBillet(d)}</div>
      <div class="grid">
        <div class="full"><label for="xSt">Statut</label><select id="xSt">${Object.entries(LIBA).map(([k,v]) => `<option value="${k}"${k === d.statut ? ' selected' : ''}>${v}</option>`).join('')}</select></div>
        <div><label for="xPf">Prix final (GNF)</label><input id="xPf" type="number" inputmode="numeric" min="0" step="5000" value="${d.prix_final_gnf ?? ''}" placeholder="${d.prix_indicatif_gnf}"></div>
        <div><label for="xRef">Réf. billet / PNR</label><input id="xRef" maxlength="40" value="${esc(d.billet_ref ?? '')}"></div>
        <div class="full"><label for="xNo">Notes internes</label><textarea id="xNo" rows="2" maxlength="1000">${esc(d.notes ?? '')}</textarea></div>
      </div>
      <div class="cards" style="margin-top:12px">
        <button class="btn btn-navy" type="button" id="xSave">Enregistrer</button>
        <button class="btn btn-wa" type="button" id="waPrix">WhatsApp au client : prix confirmé</button>
        <button class="btn btn-wa" type="button" id="waBillet">WhatsApp au client : billet prêt</button>
        <button class="btn btn-ghost" type="button" id="xTel">Appeler le client</button>
      </div>
      <p class="muted" style="margin-top:8px">Joignez le billet (PDF) dans la conversation WhatsApp qui s'ouvre.</p>`;
    voir('agDetail');
    const pf = () => +$('#xPf').value || d.prix_indicatif_gnf;
    $('#waPrix').onclick = () => ouvrir(waClient(d.telephone, `Bonjour, ici VOYAGE FACILE.\nVotre demande ${d.id} (${d.trajet}) : le prix est confirmé avec la compagnie à ${gnf(pf())} pour ${d.passagers.length} passager(s).\n${C.AGENCE_ORANGE_MONEY ? 'Pour bloquer votre place, payez par Orange Money au ' + C.AGENCE_ORANGE_MONEY + ' ou en agence, puis envoyez-nous la confirmation du paiement.' : 'Pour bloquer votre place, nous vous indiquons comment payer (Orange Money ou en agence).'}\nAttention : nous ne vous demanderons jamais votre code secret.`));
    $('#waBillet').onclick = () => ouvrir(waClient(d.telephone, `Bonjour, ici VOYAGE FACILE.\nVotre billet est prêt ! Référence de réservation : ${d.billets?.pnr || $('#xRef').value.trim() || '…'}\nTrajet : ${d.trajet}\n${d.billets?.numeros?.length ? 'N° de billet : ' + d.billets.numeros.join(', ') + '\n' : ''}Le billet électronique est ci-joint. Merci de votre confiance, et partez sans souci !`));
    $('#xTel').onclick = () => ouvrir('tel:' + d.telephone);
    $('#cpPax').onclick = async () => { try { await navigator.clipboard.writeText(paxTxt); toast('Passagers copiés'); } catch(e){ toast('Copie impossible'); } };
    brancherBillet(d);
    $('#xSave').onclick = async () => {
      const maj = { statut: $('#xSt').value, prix_final_gnf: $('#xPf').value ? Math.round(+$('#xPf').value) : null, billet_ref: $('#xRef').value.trim() || null, notes: $('#xNo').value.trim() || null, maj: new Date().toISOString() };
      const { error } = await sb.from('demandes').update(maj).eq('id', d.id);
      if (error) { toast('Enregistrement impossible'); return; }
      Object.assign(d, maj); afficher(); toast('Enregistré'); voir('agDem');
    };
  }

  /* ---------- Émission automatique du billet (Mystifly ou Duffel, choisi sur le serveur) ---------- */
  async function fnBillet(body){
    const { data, error } = await sb.functions.invoke('vf-billet', { body });
    if (error) { let m = 'Erreur pendant l\'émission'; try { const j = await error.context.json(); m = j.erreur || m; } catch(e){} throw new Error(m); }
    return data;
  }
  const hmB = iso => (iso||'').slice(11,16), jB = iso => (iso||'').slice(8,10) + '/' + (iso||'').slice(5,7);
  const badgeTest = mode => mode === 'test' ? '<div class="pill" style="display:inline-block;margin:10px 0 4px;background:#fff4e5;color:#9a5b00">MODE TEST : billets fictifs, aucun argent réel</div>' : '';
  const PAYS = [['GN','Guinée'],['SN','Sénégal'],['ML','Mali'],['CI',"Côte d'Ivoire"],['SL','Sierra Leone'],['LR','Liberia'],['GW','Guinée-Bissau'],['FR','France'],['BE','Belgique'],['US','États-Unis'],['MA','Maroc'],['CN','Chine'],['LB','Liban']];
  const optPays = v => PAYS.map(([c,n]) => `<option value="${c}"${c === v ? ' selected' : ''}>${n}</option>`).join('');

  // Contenu de l'encadré selon l'état : rien de fait / réservé, émission en cours / billet émis.
  function boiteBillet(d){
    const b = d.billets || {}, titre = `<b>Émission automatique du billet${b.fournisseur ? ' (' + esc(b.fournisseur) + ')' : ''}</b>`;
    if (b.etape === 'emis' || (d.duffel_order_id && !b.etape)) return titre + resultatEmis(b, d.billet_ref);
    if (b.ref) return titre + `<div class="box" style="margin-top:8px;background:#fff8ec">Place réservée chez ${esc(b.fournisseur)} : <b>${esc(b.ref)}</b>${b.limite ? `<br>À émettre avant le <b>${esc(jB(b.limite))} à ${esc(hmB(b.limite))}</b>` : ''}<br><span class="muted">${b.etape === 'emission' ? 'Émission demandée, en attente des numéros de billets.' : 'Billet pas encore émis.'}</span></div>
      ${badgeTest(b.mode)}<button class="btn btn-or w100" type="button" id="dfFin" style="margin-top:8px">${b.etape === 'emission' ? 'Actualiser' : 'Terminer l\'émission'}</button><div id="dfRes"></div>`;
    return titre + `<p class="muted" style="margin:6px 0 10px">Cherche ce vol chez le fournisseur de billets, puis émet le vrai billet, payé sur le solde de l'agence. À faire seulement quand le client a payé.</p>
      <button class="btn btn-navy w100" type="button" id="dfVer">Chercher ce vol</button><div id="dfRes"></div>`;
  }
  function resultatEmis(b, ref){
    return `<div class="ok" style="margin-top:8px">Billet émis${b.mode === 'test' ? ' (MODE TEST, billet fictif)' : ''} !${b.pnr ? `<br>Réf. compagnie (PNR) : <b>${esc(b.pnr)}</b>` : ''}${b.numeros?.length ? '<br>N° de billet : ' + esc(b.numeros.join(', ')) : (ref ? '<br>' + esc(ref) : '')}</div>`;
  }
  function brancherBillet(d){
    if ($('#dfVer')) $('#dfVer').onclick = () => billetVerifier(d);
    if ($('#dfFin')) $('#dfFin').onclick = () => billetTerminer(d);
  }
  function apresBillet(d, r){
    d.billets = { ...(d.billets || {}), fournisseur: r.fournisseur, mode: r.mode, etape: r.etape, ref: r.ref, pnr: r.pnr, numeros: r.numeros, limite: r.limite };
    if (r.etape === 'emis') {
      Object.assign(d, { billet_ref: r.billet_ref, statut: 'billet_envoye' });
      $('#xRef').value = r.billet_ref || ''; $('#xSt').value = 'billet_envoye';
      toast('Billet émis. Envoyez-le au client sur WhatsApp.');
    } else toast('Place réservée : ' + r.ref);
    $('#dfBox').innerHTML = boiteBillet(d); brancherBillet(d);
    if (r.etape !== 'emis' && r.message) $('#dfRes').innerHTML = `<div class="muted" style="margin-top:8px">${esc(r.message)}</div>`;
    afficher();
  }

  async function billetVerifier(d){
    const res = $('#dfRes'), bt = $('#dfVer');
    bt.disabled = true; bt.textContent = 'Recherche en cours… (jusqu\'à 1 minute)'; res.innerHTML = '';
    try {
      const j = await fnBillet({ action: 'verifier', reference: d.id });
      if (!j.offres.length) { res.innerHTML = `<div class="err" style="margin-top:8px">Aucune offre ${esc(j.fournisseur)} pour ces dates.</div>`; return; }
      res.innerHTML = `${badgeTest(j.mode)}<div class="muted" style="margin-top:6px">Offres ${esc(j.fournisseur)} :</div>
        <div>${j.offres.map((o,k) => `<label class="dfo"><input type="radio" name="dfo" value="${k}"${k===0?' checked':''}>
          <span><b>${esc(o.compagnie)}</b>${o.meme_vol ? ' <span class="pill st-confirmee">Même vol que le client</span>' : ''}${o.passeport_exige ? ' <span class="pill st-en_cours">Passeport exigé</span>' : ''}<br>
          ${o.trajets.map(t => `${esc(jB(t.depart))} ${esc(hmB(t.depart))} ${esc(t.de)} → ${esc(hmB(t.arrivee))} ${esc(t.vers)} · ${t.escales ? t.escales + ' escale(s)' : 'direct'} · ${esc(t.vols.join(' + '))}`).join('<br>')}<br>
          <b>${esc(o.montant.toFixed(2))} ${esc(o.devise)}</b>${o.gnf_estime ? ` <span class="muted"><span style="white-space:nowrap">≈ ${gnf(o.gnf_estime)}</span> <span style="white-space:nowrap">(client : ${gnf(d.prix_final_gnf ?? d.prix_indicatif_gnf)})</span></span>` : ''}
          <span class="muted">${o.modifiable === true ? ' · modifiable' : o.modifiable === false ? ' · non modifiable' : ''}${o.remboursable === true ? ' · remboursable' : o.remboursable === false ? ' · non remboursable' : ''}</span></span></label>`).join('')}</div>
        <b style="display:block;margin-top:10px">Passagers (comme sur le passeport)</b>
        ${j.passagers.map((p,k) => `<div class="grid" style="margin-top:6px">
          <div class="full muted">${k+1}. ${esc(p.nom)} ${esc(p.prenom)}</div>
          <div><label for="dfc${k}">Civilité</label><select id="dfc${k}"><option value="">—</option><option value="m"${p.civilite==='m'?' selected':''}>M. / garçon</option><option value="f"${p.civilite==='f'?' selected':''}>Mme / fille</option><option value="mlle"${p.civilite==='mlle'?' selected':''}>Mlle</option></select></div>
          <div><label for="dfn${k}">Naissance</label><input id="dfn${k}" type="date" value="${esc(p.naissance ?? '')}"></div>
          <div><label for="dfp${k}">N° passeport</label><input id="dfp${k}" maxlength="15" autocapitalize="characters" placeholder="Si exigé"></div>
          <div><label for="dfx${k}">Expire le</label><input id="dfx${k}" type="date"></div>
          <div class="full"><label for="dfy${k}">Pays du passeport</label><select id="dfy${k}">${optPays(p.passeport_pays || 'GN')}</select></div></div>`).join('')}
        <button class="btn btn-or w100" type="button" id="dfEm" style="margin-top:12px">Émettre le billet</button>`;
      $('#dfEm').onclick = () => billetEmettre(d, j);
    } catch(e) { res.innerHTML = `<div class="err" style="margin-top:8px">${esc(e.message)}</div>`; }
    finally { bt.disabled = false; bt.textContent = 'Chercher à nouveau'; }
  }

  async function billetEmettre(d, j){
    const o = j.offres[+(document.querySelector('input[name=dfo]:checked')?.value ?? 0)];
    const complements = j.passagers.map((p,k) => ({ civilite: $('#dfc'+k).value || null, naissance: $('#dfn'+k).value || null,
      passeport: $('#dfp'+k).value.replace(/\s+/g,'').toUpperCase() || null, passeport_exp: $('#dfx'+k).value || null, passeport_pays: $('#dfy'+k).value, nationalite: $('#dfy'+k).value }));
    const manque = complements.findIndex(c => !c.civilite || !c.naissance);
    if (manque >= 0) { toast(`Passager ${manque+1} : civilité et date de naissance obligatoires.`); return; }
    if (o.passeport_exige) { const k = complements.findIndex(c => !c.passeport || !c.passeport_exp); if (k >= 0) { toast(`Passager ${k+1} : cette compagnie exige le passeport (numéro et date d'expiration).`); return; } }
    const test = j.mode === 'test';
    if (!confirm(`${test ? '[MODE TEST] ' : ''}Émettre le billet ${o.compagnie} pour ${d.passagers.length} passager(s) ?\n${o.montant.toFixed(2)} ${o.devise} seront payés sur le solde ${j.fournisseur} de l'agence.\n\nLe client a-t-il bien payé ?`)) return;
    const bt = $('#dfEm'); bt.disabled = true; bt.textContent = 'Émission en cours… ne fermez pas';
    try { apresBillet(d, await fnBillet({ action: 'emettre', reference: d.id, offre_id: o.id, montant_vu: o.montant, complements })); }
    catch(e) { toast(e.message); bt.disabled = false; bt.textContent = 'Émettre le billet'; }
  }

  async function billetTerminer(d){
    const b = d.billets || {};
    if (b.etape === 'reserve' && !confirm(`Émettre maintenant le billet réservé ${b.ref} ?\nLe montant sera payé sur le solde ${b.fournisseur} de l'agence.`)) return;
    const bt = $('#dfFin'); bt.disabled = true; bt.textContent = 'Un instant…';
    try { apresBillet(d, await fnBillet({ action: 'finaliser', reference: d.id })); }
    catch(e) { toast(e.message); bt.disabled = false; bt.textContent = b.etape === 'emission' ? 'Actualiser' : 'Terminer l\'émission'; }
  }

  $('#goReg').onclick = async () => {
    const { data, error } = await sb.from('reglages').select('*').eq('id',1).single();
    if (error || !data) { toast('Réglages inaccessibles'); return; }
    $('#rUSD').value = data.taux?.USD ?? ''; $('#rEUR').value = data.taux?.EUR ?? '';
    $('#rPct').value = data.commission_pct; $('#rMin').value = data.commission_min; $('#rArr').value = data.arrondi;
    $('#rVal').value = data.duree_validite_min; $('#rMar').value = data.marche;
    $('#regMaj').textContent = 'Dernière mise à jour : ' + new Date(data.maj).toLocaleString('fr-FR');
    voir('agReg');
  };
  $('#agReg').addEventListener('submit', async e => {
    e.preventDefault();
    const n = (id, min) => { const v = Math.round(+$(id).value); return isFinite(v) && v >= min ? v : null; };
    const maj = { taux: { USD: n('#rUSD',1), EUR: n('#rEUR',1) }, commission_pct: +$('#rPct').value, commission_min: n('#rMin',0), arrondi: n('#rArr',1),
      duree_validite_min: n('#rVal',10), marche: $('#rMar').value.trim().toUpperCase(), maj: new Date().toISOString() };
    if (!maj.taux.USD || !maj.taux.EUR || maj.commission_min == null || !maj.arrondi || !maj.duree_validite_min || !(maj.commission_pct >= 0 && maj.commission_pct <= 50) || !/^[A-Z]{2}$/.test(maj.marche)) { toast('Vérifiez les valeurs saisies.'); return; }
    const { error } = await sb.from('reglages').update(maj).eq('id',1);
    if (error) { toast('Enregistrement impossible'); return; }
    toast('Réglages enregistrés'); voir('agDem');
  });

  sb.auth.onAuthStateChange(ev => { if (ev === 'SIGNED_OUT' && NAV.vue === 'agence') voir('fLogin'); });
  window.Agence = { ouvrir: ouvrirAgence, retour };
})();
