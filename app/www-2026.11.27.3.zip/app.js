/* =====================================================================
   VOYAGE FACILE — application Android (client + espace agence)
   Le moteur est sur Supabase (fonction "vf-api") : prix calculés et
   vérifiés par le serveur, alerte WhatsApp envoyée par le serveur.
   ===================================================================== */
const C = window.VF_CONFIG;
const VERSION = "1.0.0";
const API = C.SUPABASE_URL + "/functions/v1/vf-api";
const $ = s => document.querySelector(s);
const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const T = (s, v) => window.L ? L.t(s, v) : s;
const LOC = (window.L && L.loc) || 'fr-FR';
const gnf = n => (n == null ? '—' : Math.round(n).toLocaleString(LOC).replace(/[  ]/g,' ') + ' GNF');
const P = () => (window.Capacitor && window.Capacitor.Plugins) || {};
function toast(t){ const el=$('#toast'); el.textContent=t; el.style.display='block'; clearTimeout(toast.t); toast.t=setTimeout(()=>el.style.display='none',2800); }

/* Ouvre WhatsApp, le téléphone ou l'e-mail avec l'application du téléphone */
function ouvrir(url){
  const AL = P().AppLauncher;
  if (AL) AL.openUrl({ url }).catch(() => { window.location.href = url; });
  else window.open(url, '_blank');
}
const waAgence = t => 'https://wa.me/' + C.AGENCE_WHATSAPP + '?text=' + encodeURIComponent(t);

/* Stockage local (les voyages du client restent sur son téléphone) */
const store = {
  get(k, d){ try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch(e){ return d; } },
  set(k, v){ try { localStorage.setItem(k, JSON.stringify(v)); } catch(e){} }
};

async function api(action, data){
  let r;
  try {
    r = await fetch(API, { method:'POST', headers:{ 'Content-Type':'application/json', 'apikey':C.SUPABASE_ANON_KEY, 'Authorization':'Bearer ' + C.SUPABASE_ANON_KEY },
      body: JSON.stringify({ action, devise: window.Devise ? Devise.code() : 'GNF', langue: window.L ? L.code : 'fr', ...data }) });
  } catch(e){ throw new Error(T("Pas de connexion Internet. Vérifiez votre réseau puis réessayez.")); }
  let j = {}; try { j = await r.json(); } catch(e){}
  if(!r.ok) throw new Error(j.erreur || T("Le service ne répond pas. Réessayez ou écrivez-nous sur WhatsApp."));
  return j;
}

/* ---------------- Navigation ---------------- */
const NAV = { vue: 'accueil', sous: null };   // sous-écran (étapes des vols, écrans agence)
function montrer(vue){
  NAV.vue = vue;
  document.querySelectorAll('.view').forEach(v => v.hidden = v.id !== 'v-' + vue);
  document.querySelectorAll('#tabs button').forEach(b => b.setAttribute('aria-selected', b.dataset.v === vue));
  $('#tabs').hidden = vue === 'agence';
  entete(vue === 'agence' ? 'Espace agence' : vue === 'aide' ? T('Aide et contact') : null);
  $('#main').scrollTop = 0;
  $('#main').classList.toggle('chat', vue === 'assistant');
  if (vue === 'voyages') chargerVoyages();
  if (vue === 'accueil') dernierVoyage();
  if (vue === 'agence' && window.Agence) window.Agence.ouvrir();
}
function entete(titre){
  const sub = !!titre;
  $('#back').hidden = !sub; $('#barTitle').hidden = !sub; $('#brandTxt').hidden = sub; $('#brand').hidden = sub; $('#helpBtn').hidden = sub; if ($('#langBtn')) $('#langBtn').hidden = sub;
  if (sub) $('#barTitle').textContent = titre;
}
document.querySelectorAll('#tabs button').forEach(b => b.onclick = () => montrer(b.dataset.v));
$('#back').onclick = () => retour();
$('#helpBtn').onclick = () => montrer('aide');

function etapeVols(id){
  ['volsSearch','volsPax','volsDone'].forEach(x => $('#'+x).hidden = x !== id);
  NAV.sous = id === 'volsSearch' ? null : id;
  $('#main').scrollTop = 0;
}
// Bouton retour d'Android : revient en arrière dans l'application avant de la fermer.
function retour(){
  if (document.querySelector('.sheet-bg')) { fermerFeuille(); return true; }
  if (NAV.vue === 'agence') { if (window.Agence && window.Agence.retour()) return true; montrer('aide'); return true; }
  if (NAV.vue === 'vols' && NAV.sous === 'volsPax') { etapeVols('volsSearch'); return true; }
  if (NAV.vue === 'vols' && NAV.sous === 'volsDone') { etapeVols('volsSearch'); return true; }
  if (NAV.vue !== 'accueil') { montrer('accueil'); return true; }
  return false;
}
document.addEventListener('DOMContentLoaded', () => {
  const App = P().App;
  if (App) App.addListener('backButton', () => { if (!retour()) App.exitApp(); });
  const SB = P().StatusBar; if (SB) { SB.setBackgroundColor({ color:'#0b2545' }).catch(()=>{}); SB.setStyle({ style:'DARK' }).catch(()=>{}); }
});

/* ---------------- VOLS ---------------- */
let RECH = null, CHOIX = null, PARAMS = null;
// Tri et filtres : le client trouve vite le vol qu'il préfère et le choisit directement.
let FILTRE = { tri:'prix', direct:false, compagnie:'', soute:false };
const dureeTot = o => (o.aller?.duree_min || 0) + (o.retour?.duree_min || 0);
const estDirect = o => o.aller.escales === 0 && (!o.retour || o.retour.escales === 0);
function renderOffres(){
  const p = PARAMS, toutes = RECH.offres;
  const comps = [...new Set(toutes.map(o => o.aller.compagnie).filter(Boolean))].sort();
  const moinsCher = Math.min(...toutes.map(o => o.total_gnf)), plusRapide = Math.min(...toutes.map(dureeTot));
  let l = toutes.filter(o => (!FILTRE.direct || estDirect(o)) && (!FILTRE.compagnie || o.aller.compagnie === FILTRE.compagnie) && (!FILTRE.soute || (o.bagages && o.bagages.soute > 0)));
  const tri = { prix:(a,b) => a.total_gnf - b.total_gnf, duree:(a,b) => dureeTot(a) - dureeTot(b), heure:(a,b) => a.aller.depart_heure.localeCompare(b.aller.depart_heure) }[FILTRE.tri];
  l.sort(tri);
  const chip = (cle, val, txt) => `<button type="button" data-${cle}="${val}" aria-pressed="${cle==='tri' ? FILTRE.tri===val : !!FILTRE[val]}">${txt}</button>`;
  const barre = `<div class="filters" id="triBar">${chip('tri','prix','Moins cher')}${chip('tri','duree','Plus rapide')}${chip('tri','heure','Départ tôt')}${chip('f','direct','Direct uniquement')}${chip('f','soute','Bagage en soute')}</div>
    ${comps.length > 1 ? `<select id="compSel" aria-label="Compagnie" style="margin-bottom:10px"><option value="">${T('Toutes les compagnies ({n})', { n: comps.length })}</option>${comps.map(c => `<option${c===FILTRE.compagnie?' selected':''}>${esc(c)}</option>`).join('')}</select>` : ''}`;
  const badge = o => [o.total_gnf === moinsCher ? '<span class="pill st-billet_envoye">Le moins cher</span>' : '', dureeTot(o) === plusRapide ? '<span class="pill st-en_cours">Le plus rapide</span>' : '', estDirect(o) ? '<span class="pill st-confirmee">Direct</span>' : ''].join(' ');
  $('#results').innerHTML = barreDevise() + `<p class="muted">${T('{n} vol(s) sur {t} · prix pour {p} passager(s), commission comprise. Prix confirmé par votre conseiller avant paiement.', { n: l.length, t: toutes.length, p: p.adultes + p.enfants })}</p>` + barre +
    (l.length ? l.map(o => `<article class="offer"><div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:6px">${badge(o)}</div>${legHTML(o.aller,'Aller')}${legHTML(o.retour,'Retour')}${bagages(o)}
      <div class="foot"><div><b>${Devise.html(o.total_gnf)}</b><span class="muted">total</span></div><button class="btn btn-or" type="button" data-i="${o.i}">Choisir ce vol</button></div></article>`).join('')
     : `<div class="panel">Aucun vol avec ces critères. <button class="btn btn-ghost w100" style="margin-top:10px" type="button" id="resetF">Voir tous les vols</button></div>`);
  $('#results').querySelectorAll('button[data-i]').forEach(b => b.onclick = () => choisir(+b.dataset.i));
  if ($('#chgDevise')) $('#chgDevise').onclick = () => montrer('aide');
  $('#triBar').querySelectorAll('[data-tri]').forEach(b => b.onclick = () => { FILTRE.tri = b.dataset.tri; renderOffres(); });
  $('#triBar').querySelectorAll('[data-f]').forEach(b => b.onclick = () => { FILTRE[b.dataset.f] = !FILTRE[b.dataset.f]; renderOffres(); });
  if ($('#compSel')) $('#compSel').onchange = e => { FILTRE.compagnie = e.target.value; renderOffres(); };
  if ($('#resetF')) $('#resetF').onclick = () => { FILTRE = { tri: FILTRE.tri, direct:false, compagnie:'', soute:false }; renderOffres(); };
}
for(let i=1;i<=9;i++) $('#ad').insertAdjacentHTML('beforeend', `<option>${i}</option>`);
for(let i=0;i<=8;i++) $('#ch').insertAdjacentHTML('beforeend', `<option>${i}</option>`);
const today = new Date().toISOString().slice(0,10);
$('#d1').min = today; $('#d2').min = today;
document.querySelectorAll('input[name=trip]').forEach(r => r.onchange = () => { $('#d2box').hidden = document.querySelector('input[name=trip]:checked').value === 'as'; });
$('#d1').onchange = () => { $('#d2').min = $('#d1').value || today; if($('#d2').value && $('#d2').value < $('#d1').value) $('#d2').value = ''; };
$('#swap').onclick = () => { const a=$('#from'), b=$('#to'); [a.value,b.value]=[b.value,a.value]; [a.dataset.code,b.dataset.code]=[b.dataset.code||'',a.dataset.code||'']; };

function autocomplete(inp, list){
  let t = null, items = [];
  const close = () => { list.hidden = true; };
  const pick = a => { inp.value = `${a.ville} (${a.code})`; inp.dataset.code = a.code; close(); inp.blur(); };
  inp.addEventListener('input', () => {
    inp.dataset.code = ''; clearTimeout(t);
    const q = inp.value.trim(); if(q.length < 2){ close(); return; }
    t = setTimeout(async () => {
      try {
        const j = await api('aeroports', { q }); items = j.aeroports || [];
        list.innerHTML = items.length ? items.map((a,i) => `<li data-i="${i}"><b>${esc(a.ville)}</b> (${esc(a.code)})<div class="muted">${esc(a.nom)} · ${esc(a.pays)}</div></li>`).join('') : '<li class="muted">Aucun aéroport trouvé</li>';
        list.hidden = false;
        list.querySelectorAll('li[data-i]').forEach(li => li.addEventListener('pointerdown', e => { e.preventDefault(); pick(items[li.dataset.i]); }));
      } catch(e){ close(); }
    }, 300);
  });
  inp.addEventListener('blur', () => setTimeout(close, 200));
  inp.addEventListener('focus', () => { if(inp.dataset.code) inp.select(); });
}
autocomplete($('#from'), $('#fromList'));
autocomplete($('#to'), $('#toList'));
// Si le client tape une ville sans toucher la liste, on prend le premier aéroport trouvé.
async function resoudre(inp){
  if(inp.dataset.code) return inp.dataset.code;
  const q = inp.value.trim(); if(q.length < 2) return '';
  const m = q.match(/^([A-Za-z]{3})$/) || q.match(/\(([A-Za-z]{3})\)\s*$/);
  if(m){ inp.dataset.code = m[1].toUpperCase(); return inp.dataset.code; }
  try {
    const j = await api('aeroports', { q }); const a = (j.aeroports || [])[0];
    if(a){ inp.value = `${a.ville} (${a.code})`; inp.dataset.code = a.code; return a.code; }
  } catch(e){}
  return '';
}

const heure = iso => (iso||'').slice(11,16);
const jour = iso => { const d = new Date((iso||'').slice(0,10)+'T12:00:00'); return isNaN(d) ? '' : d.toLocaleDateString(LOC,{weekday:'short',day:'numeric',month:'short'}); };
const duree = m => m ? `${Math.floor(m/60)} h ${String(m%60).padStart(2,'0')}` : '';
const escales = t => t.escales ? `${T('{n} escale(s)', { n: t.escales })} · ${t.escales_aeroports.join(', ')}` : T('Direct');
function legHTML(t, titre){
  if(!t) return '';
  const plus = t.arrivee_heure.slice(0,10) !== t.depart_heure.slice(0,10) ? ' <span class="muted">+1</span>' : '';
  return `<div class="muted">${esc(T(titre))} · ${esc(jour(t.depart_heure))} · ${esc(t.compagnie)}</div>
   <div class="leg"><span class="t">${esc(heure(t.depart_heure))}</span><span class="muted">${esc(t.depart_aeroport)}</span>
   <span class="line"><span>${esc(duree(t.duree_min))} · ${esc(escales(t))}</span></span>
   <span class="muted">${esc(t.arrivee_aeroport)}</span><span class="t">${esc(heure(t.arrivee_heure))}${plus}</span></div>`;
}
function bagages(o){ if(!o.bagages) return ''; const b=o.bagages, p=[]; if(b.cabine!=null) p.push(T('{n} bagage cabine', { n: b.cabine })); if(b.soute!=null) p.push(b.soute ? T('{n} en soute', { n: b.soute }) : T('pas de bagage en soute')); return p.length ? `<div class="muted bag">${ico('luggage',16)} ${esc(p.join(' · '))}</div>` : ''; }

$('#fSearch').addEventListener('submit', async e => {
  e.preventDefault(); $('#eSearch').hidden = true;
  const ar = document.querySelector('input[name=trip]:checked').value === 'ar';
  $('#bSearch').disabled = true;
  await resoudre($('#from')); await resoudre($('#to'));
  $('#bSearch').disabled = false;
  const p = { origine: $('#from').dataset.code, destination: $('#to').dataset.code, date_aller: $('#d1').value,
              date_retour: ar ? $('#d2').value : null, adultes: +$('#ad').value, enfants: +$('#ch').value, classe: $('#cl').value };
  const errs = [];
  if(!p.origine) errs.push(T("la ville de départ (vérifiez l'orthographe)"));
  if(!p.destination) errs.push(T("la destination (vérifiez l'orthographe)"));
  if(!p.date_aller) errs.push(T('la date de départ'));
  if(ar && !p.date_retour) errs.push(T('la date de retour'));
  if(errs.length){ $('#eSearch').textContent = T('Merci de compléter : {liste}.', { liste: errs.join(', ') }); $('#eSearch').hidden = false; return; }
  $('#bSearch').disabled = true; $('#results').innerHTML = ''; $('#loading').hidden = false;
  try {
    const j = await api('recherche', p);
    PARAMS = p; RECH = j;
    if(!j.offres || !j.offres.length){
      $('#results').innerHTML = `<div class="panel">${esc(j.message || 'Aucun vol trouvé.')}<button class="btn btn-wa w100" style="margin-top:10px" type="button" id="waNone">Demander à un conseiller</button></div>`;
      $('#waNone').onclick = () => ouvrir(waAgence(T('Bonjour VOYAGE FACILE, je cherche un vol {o} → {d} le {j}.', { o: p.origine, d: p.destination, j: p.date_aller })));
      return;
    }
    FILTRE = { tri:'prix', direct: $('#direct').checked, compagnie:'', soute:false };
    renderOffres();
    setTimeout(() => $('#results').scrollIntoView({behavior:'smooth'}), 50);
  } catch(err){ $('#eSearch').textContent = err.message; $('#eSearch').hidden = false; }
  finally { $('#bSearch').disabled = false; $('#loading').hidden = true; }
});

// Date de naissance en 3 listes (jour, mois, année) : bien plus rapide que le calendrier.
const MOIS = ['janvier','février','mars','avril','mai','juin','juillet','août','septembre','octobre','novembre','décembre'];
function champNaissance(k, enfant){
  const an = new Date().getFullYear();
  const debut = enfant ? an - 12 : 1920, fin = enfant ? an : an - 12;
  const ans = []; for(let y = fin; y >= debut; y--) ans.push(y);
  const opt = (v, t) => `<option value="${v}">${t}</option>`;
  return `<div class="naiss">
    <select id="pdj${k}" aria-label="Jour">${opt('','Jour')}${Array.from({length:31},(_,i)=>opt(i+1,i+1)).join('')}</select>
    <select id="pdm${k}" aria-label="Mois">${opt('','Mois')}${MOIS.map((m,i)=>opt(i+1,m)).join('')}</select>
    <select id="pda${k}" aria-label="Année">${opt('','Année')}${ans.map(y=>opt(y,y)).join('')}</select></div>`;
}
// Renvoie AAAA-MM-JJ, null si rien n'est choisi, false si incomplet ou impossible (ex. 31 février).
function lireNaissance(k){
  const j = +$('#pdj'+k).value, m = +$('#pdm'+k).value, a = +$('#pda'+k).value;
  if(!j && !m && !a) return null;
  if(!j || !m || !a) return false;
  const d = new Date(Date.UTC(a, m-1, j));
  if(d.getUTCDate() !== j || d.getUTCMonth() !== m-1 || d > new Date()) return false;
  return `${a}-${String(m).padStart(2,'0')}-${String(j).padStart(2,'0')}`;
}
function choisir(i){
  CHOIX = RECH.offres.find(o => o.i === i); if(!CHOIX) return;
  const n = PARAMS.adultes + PARAMS.enfants; let h = '';
  for(let k=0;k<n;k++){
    const enfant = k >= PARAMS.adultes;
    h += `<div class="pax"><h4>${T(enfant ? 'Passager {n} (enfant)' : 'Passager {n}', { n: k+1 })}</h4><div class="grid">
      <div class="full"><label for="pc${k}">Civilité</label><div class="civ" role="radiogroup" id="pc${k}">
        <label><input type="radio" name="civ${k}" value="m"> ${enfant ? 'Garçon' : 'Monsieur'}</label>
        <label><input type="radio" name="civ${k}" value="f"> ${enfant ? 'Fille' : 'Madame'}</label>${enfant ? '' : `
        <label><input type="radio" name="civ${k}" value="mlle"> Mademoiselle</label>`}</div></div>
      <div><label for="pp${k}">Prénom(s)</label><input id="pp${k}" autocomplete="given-name"></div>
      <div><label for="pn${k}">Nom</label><input id="pn${k}" autocomplete="family-name"></div>
      <div class="full"><label for="pdj${k}">Date de naissance</label>${champNaissance(k, enfant)}</div></div></div>`;
  }
  $('#paxList').innerHTML = h;
  const moi = store.get('vf_moi', {});
  if (moi.tel && !$('#tel').value) $('#tel').value = moi.tel;
  if (moi.mail && !$('#mail').value) $('#mail').value = moi.mail;
  $('#recap').innerHTML = `${legHTML(CHOIX.aller,'Aller')}${legHTML(CHOIX.retour,'Retour')}<div style="margin-top:6px"><b>${T('Total : {p}', { p: Devise.html(CHOIX.total_gnf) })}</b> <span class="muted">${T('({n} passager(s))', { n })}</span></div>`;
  $('#ePax').hidden = true; etapeVols('volsPax');
}
function fail(m){ $('#ePax').textContent = m; $('#ePax').hidden = false; }
$('#fPax').addEventListener('submit', async e => {
  e.preventDefault(); $('#ePax').hidden = true;
  const n = PARAMS.adultes + PARAMS.enfants, passagers = [];
  for(let k=0;k<n;k++){
    const prenom = $('#pp'+k).value.trim(), nom = $('#pn'+k).value.trim();
    const N = { n: k+1 };
    if(!prenom || !nom) return fail(T('Passager {n} : indiquez le prénom et le nom.', N));
    const civ = document.querySelector(`input[name=civ${k}]:checked`);
    if(!civ) return fail(T(k >= PARAMS.adultes ? 'Passager {n} : choisissez Garçon ou Fille.' : 'Passager {n} : choisissez Monsieur, Madame ou Mademoiselle.', N));
    const naissance = lireNaissance(k);
    if(naissance === false) return fail(T('Passager {n} : date de naissance incomplète ou impossible (jour, mois et année).', N));
    if(!naissance) return fail(T('Passager {n} : la date de naissance est nécessaire pour émettre le billet.', N));
    passagers.push({ prenom, nom, naissance, civilite: civ.value });
  }
  const tel = $('#tel').value.trim();
  if(!tel) return fail(T('Indiquez votre numéro WhatsApp.'));
  if(!$('#ok').checked) return fail(T('Cochez la case pour confirmer votre demande.'));
  $('#bSend').disabled = true; $('#bSend').textContent = T('Envoi…');
  try {
    const j = await api('demande', { recherche_id: RECH.recherche_id, offre: CHOIX.i, passagers, telephone: tel, email: $('#mail').value || null, message: $('#msg').value || null, accord: true });
    store.set('vf_moi', { tel, mail: $('#mail').value || '' });
    const voyages = store.get('vf_voyages', []);
    voyages.unshift({ reference: j.reference, telephone: tel, trajet: `${PARAMS.origine} → ${PARAMS.destination}`, aller: CHOIX.aller, retour: CHOIX.retour,
      passagers: passagers.map(p => p.prenom + ' ' + p.nom.toUpperCase()), total: j.total_gnf, cree: new Date().toISOString(), statut: 'nouvelle' });
    store.set('vf_voyages', voyages.slice(0, 50));
    $('#ref').textContent = j.reference;
    const trajetTxt = `${PARAMS.origine} → ${PARAMS.destination}`, prixTxt = Devise.prix(j.total_gnf) + (Devise.code() !== 'GNF' ? ', ' + gnf(j.total_gnf) : '');
    $('#waDone').onclick = () => ouvrir(waAgence(T("Bonjour VOYAGE FACILE, je viens d'envoyer la demande {r} ({t}, {p}).", { r: j.reference, t: trajetTxt, p: prixTxt })));
    $('#fPax').reset(); etapeVols('volsDone');
  } catch(err){ fail(err.message); }
  finally { $('#bSend').disabled = false; $('#bSend').textContent = T('Envoyer ma demande'); }
});
$('#bNew').onclick = () => { $('#results').innerHTML = ''; etapeVols('volsSearch'); };
$('#goVoyages').onclick = () => { etapeVols('volsSearch'); $('#results').innerHTML=''; montrer('voyages'); };

/* ---------------- MES VOYAGES ---------------- */
const ETAPES = { nouvelle:1, en_cours:2, confirmee:3, billet_envoye:4, annulee:0 };
const LIB = { nouvelle:'Reçue', en_cours:'En vérification', confirmee:'Prix confirmé', billet_envoye:'Billet envoyé', annulee:'Annulée' };
const EXPL = {
  nouvelle: "Votre conseiller vérifie le prix et les places avec la compagnie.",
  en_cours: "Votre conseiller est en train de vérifier avec la compagnie.",
  confirmee: "Le prix est confirmé. Payez avec Orange Money ci-dessous, ou en agence.",
  billet_envoye: "Votre billet vous a été envoyé sur WhatsApp. Bon voyage !",
  annulee: "Cette demande a été annulée. Écrivez-nous pour une nouvelle recherche."
};
// Compte à rebours avant le départ (jours de calendrier, heure locale du téléphone).
function joursAvant(iso){
  if (!iso) return null;
  const d = new Date(String(iso).slice(0,10) + 'T00:00:00'), auj = new Date(); auj.setHours(0,0,0,0);
  return isNaN(d) ? null : Math.round((d - auj) / 864e5);
}
const texteDepart = n => n === 0 ? T("Départ aujourd'hui") : n === 1 ? T('Départ demain') : T('Départ dans {n} jours', { n });
// Liste de préparation (cochée sur le téléphone du client)
const PREP = ['Passeport valable au moins 6 mois après la date de retour', "Visa ou autorisation d'entrée vérifiés (si nécessaire)",
  'Carnet de vaccination (fièvre jaune) dans le bagage à main', 'Billet et référence enregistrés sur le téléphone',
  'Bagages pesés selon la franchise de la compagnie', "Arriver à l'aéroport 3 heures avant le départ"];
function blocPreparation(x){
  if (x.statut === 'annulee') return '';
  const n = joursAvant(x.aller?.depart_heure);
  if (n == null || n < 0 || n > 330) return '';
  const coches = (store.get('vf_prep', {})[x.reference] || []);
  return `<details class="prep"${n <= 7 ? ' open' : ''}><summary><span class="prep-j">${esc(texteDepart(n))}</span><span class="muted">${esc(T('Préparation {a}/{b}', { a: coches.length, b: PREP.length }))}</span></summary>
    ${PREP.map((t, k) => `<label class="check"><input type="checkbox" data-prep="${esc(x.reference)}" value="${k}"${coches.includes(k) ? ' checked' : ''}> <span>${esc(T(t))}</span></label>`).join('')}</details>`;
}
// « Faire payer un proche » : tant que le billet n'est pas payé ni annulé.
const peutFairePayer = x => ['nouvelle','en_cours','confirmee'].includes(x.statut) && !(x.paiement && ['recu','declare'].includes(x.paiement.statut));
async function fairePayerProche(x, bouton){
  const texte = bouton.textContent; bouton.disabled = true; bouton.textContent = T('Un instant…');
  try {
    const j = await api('lien_proche', { reference: x.reference, telephone: x.telephone });
    const msg = T("Bonjour, peux-tu m'aider à payer mon billet d'avion VOYAGE FACILE ({t}) ? Tu vois le montant et tu paies en toute sécurité ici : {u}", { t: x.trajet, u: j.url });
    const Share = P().Share;
    if (Share) await Share.share({ text: msg, dialogTitle: T('Faire payer un proche') }).catch(() => ouvrir('https://wa.me/?text=' + encodeURIComponent(msg)));
    else { ouvrir('https://wa.me/?text=' + encodeURIComponent(msg)); toast(T('Lien de paiement prêt : choisissez la personne sur WhatsApp.')); }
  } catch(e){ toast(e.message); }
  finally { bouton.disabled = false; bouton.textContent = texte; }
}
// Billet électronique joint par l'agence : le serveur donne un lien de téléchargement valable quelques minutes.
async function telechargerBillet(x, bouton){
  const texte = bouton.innerHTML; bouton.disabled = true; bouton.textContent = T('Un instant…');
  try {
    const j = await api('billet', { reference: x.reference, telephone: x.telephone });
    ouvrir(j.url); toast(T('Ouverture de votre billet…'));
  } catch(e){ toast(e.message); }
  finally { bouton.disabled = false; bouton.innerHTML = texte; }
}
function afficherVoyages(){
  const v = store.get('vf_voyages', []);
  if (!v.length) { $('#voyages').innerHTML = `<div class="panel" style="text-align:center"><p>${T("Aucun voyage pour l'instant.")}</p><button class="btn btn-or w100" type="button" style="margin-top:10px" id="goSearch">${T('Chercher un vol')}</button></div>`; $('#goSearch').onclick = () => montrer('vols'); return; }
  $('#voyages').innerHTML = v.map(x => {
    const e = ETAPES[x.statut] ?? 1;
    return `<div class="card"><div class="top"><div><b>${esc(x.trajet)}</b><div class="muted">${esc(T('Réf. {r}', { r: x.reference }))} · ${esc(jour(x.aller?.depart_heure))}</div></div><span class="pill st-${esc(x.statut)}">${esc(T(LIB[x.statut] || x.statut))}</span></div>
      ${x.statut === 'annulee' ? '' : `<div class="steps4">${[1,2,3,4].map(k => `<i class="${k <= e ? 'on' : ''}"></i>`).join('')}</div>`}
      <p class="muted" style="margin:6px 0">${esc(T(x.statut === 'billet_envoye' && x.billet_fichier ? 'Votre billet est prêt : téléchargez-le ci-dessous. Bon voyage !' : (EXPL[x.statut] || '')))}</p>
      <div class="row2"><span class="muted">${T(x.prix_confirme ? 'Prix confirmé' : 'Prix indicatif')}</span><b style="text-align:right">${Devise.html(x.prix ?? x.total)}</b></div>
      ${x.billet_ref ? `<div class="row2"><span class="muted">${T('Référence billet')}</span><b>${esc(x.billet_ref)}</b></div>` : ''}
      ${x.billet_fichier ? `<button class="btn btn-or w100" type="button" style="margin-top:10px" data-billet="${esc(x.reference)}">${ico('file-check-2',20)} ${T('Télécharger mon billet')}</button>` : ''}
      <div class="muted" style="margin-top:4px" data-no-t>${esc((x.passagers||[]).join(', '))}</div>
      ${blocPreparation(x)}
      <div data-pay-box="${esc(x.reference)}">${window.Paiement ? Paiement.html(x, store.get('vf_pay_infos', null)) : ''}</div>
      ${peutFairePayer(x) ? `<button class="btn btn-ghost w100" type="button" style="margin-top:10px" data-proche="${esc(x.reference)}">${ico('users',18)} ${T('Faire payer un proche')}</button>` : ''}
      <button class="btn btn-wa w100" type="button" style="margin-top:10px" data-wa="${esc(x.reference)}">${T("Écrire à l'agence")}</button></div>`;
  }).join('');
  $('#voyages').querySelectorAll('[data-wa]').forEach(b => b.onclick = () => ouvrir(waAgence(T('Bonjour VOYAGE FACILE, au sujet de ma demande {r} :', { r: b.dataset.wa }))));
  $('#voyages').querySelectorAll('[data-billet]').forEach(b => b.onclick = () => telechargerBillet(v.find(x => x.reference === b.dataset.billet), b));
  $('#voyages').querySelectorAll('[data-proche]').forEach(b => b.onclick = () => fairePayerProche(v.find(x => x.reference === b.dataset.proche), b));
  $('#voyages').querySelectorAll('[data-prep]').forEach(c => c.onchange = () => {
    const tout = store.get('vf_prep', {}), ref = c.dataset.prep;
    const l = new Set(tout[ref] || []); c.checked ? l.add(+c.value) : l.delete(+c.value);
    tout[ref] = [...l].sort(); store.set('vf_prep', tout);
    const s = c.closest('details').querySelector('summary .muted'); if (s) s.textContent = T('Préparation {a}/{b}', { a: l.size, b: PREP.length });
  });
  if (window.Paiement) v.forEach(x => Paiement.brancher($('#voyages').querySelector(`[data-pay-box="${CSS.escape(x.reference)}"]`), x,
    { api, ouvrir, toast, apres: chargerVoyages }));
}
async function chargerVoyages(){
  afficherVoyages();
  const v = store.get('vf_voyages', []); if (!v.length) return;
  try {
    const j = await api('suivi', { demandes: v.map(x => ({ reference: x.reference, telephone: x.telephone })) });
    const m = {}; (j.demandes || []).forEach(d => m[d.reference] = d);
    v.forEach(x => { const d = m[x.reference]; if (d) { x.statut = d.statut; x.prix = d.prix_gnf; x.prix_gnf = d.prix_gnf; x.prix_confirme = d.prix_confirme; x.billet_ref = d.billet_ref; x.paiement = d.paiement; x.a_payer = d.a_payer; x.billet_fichier = !!d.billet_fichier; } });
    if (j.paiement_infos) store.set('vf_pay_infos', j.paiement_infos);
    store.set('vf_voyages', v); afficherVoyages();
  } catch(e){ toast(e.message); }
}
$('#bRefresh').onclick = () => { chargerVoyages(); toast(T('Mise à jour…')); };
// Retour depuis la page Orange Money : on actualise l'état du paiement.
document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible' && NAV.vue === 'voyages') chargerVoyages(); });

/* ---------------- SERVICES ---------------- */
const SERVICES = [
  { id:'hotel', ic:'bed-double', photo:'img/hotel.jpg', titre:'Hôtel', sous:'Toutes les villes, tous budgets',
    champs:[['Ville','text'],["Date d'arrivée",'date'],['Date de départ','date'],['Personnes','number'],['Budget par nuit (GNF)','text']] },
  { id:'visa', ic:'stamp', photo:'img/visa.jpg', titre:'Visa', sous:'Dossier, rendez-vous, suivi',
    champs:[['Pays du visa','text'],['Type (tourisme, affaires, études…)','text'],['Date de voyage prévue','date'],['Nombre de personnes','number']] },
  { id:'hajj', ic:'moon-star', photo:'img/hajj.jpg', titre:'Hajj & Omra', sous:'Formules complètes',
    champs:[['Formule (Omra, Omra Ramadan, Hajj)','text'],['Période souhaitée','text'],['Nombre de pèlerins','number'],['Confort (standard, confort, VIP)','text']] },
  { id:'assurance', ic:'shield-check', photo:'img/assurance.jpg', titre:'Assurance voyage', sous:'Santé et rapatriement',
    champs:[['Destination','text'],['Date de départ','date'],['Date de retour','date'],['Nombre de voyageurs','number']] },
];
const carteService = s => `<button type="button" data-s="${s.id}"><img src="${s.photo}" alt="" loading="lazy"><span class="cap"><span class="ic">${ico(s.ic,18)}</span><b>${esc(T(s.titre))}</b><span>${esc(T(s.sous))}</span></span></button>`;
['#svc','#homeSvc'].forEach(sel => {
  $(sel).innerHTML = SERVICES.map(carteService).join('');
  $(sel).querySelectorAll('button').forEach(b => b.onclick = () => feuilleService(SERVICES.find(s => s.id === b.dataset.s)));
});
function feuilleService(s){
  const moi = store.get('vf_moi', {});
  ouvrirFeuille(`<img class="sheet-photo" src="${s.photo}" alt=""><h2 class="ttl">${ico(s.ic)} ${esc(T(s.titre))}</h2><form id="fSvc" class="grid">
    ${s.champs.map(([l,t],k) => `<div class="full"><label for="sv${k}">${esc(T(l))}</label><input id="sv${k}" type="${t}"${t==='number'?' inputmode="numeric" min="1"':''}></div>`).join('')}
    <div class="full"><label for="svNom">Votre nom</label><input id="svNom"></div>
    <div class="full"><label for="svMsg">Précisions (facultatif)</label><textarea id="svMsg" rows="2"></textarea></div>
    <button class="btn btn-wa full" type="submit">${ico('send',20)} Envoyer sur WhatsApp</button></form>`);
  $('#fSvc').onsubmit = e => {
    e.preventDefault();
    const lignes = s.champs.map(([l],k) => { const v = $('#sv'+k).value.trim(); return v ? `${T(l)} : ${v}` : null; }).filter(Boolean);
    if (!lignes.length) { toast(T('Remplissez au moins une information.')); return; }
    const nom = $('#svNom').value.trim(), msg = $('#svMsg').value.trim();
    const t = `${T('Bonjour VOYAGE FACILE, demande : {s}', { s: T(s.titre) })}\n${lignes.join('\n')}${nom ? '\n' + T('Nom : {n}', { n: nom }) : ''}${msg ? '\n' + msg : ''}`;
    fermerFeuille(); ouvrir(waAgence(t));
  };
}
function ouvrirFeuille(html){
  $('#sheetHost').innerHTML = `<div class="sheet-bg"><div class="sheet" role="dialog" aria-modal="true"><div class="grab"></div>${html}</div></div>`;
  $('.sheet-bg').addEventListener('click', e => { if (e.target.classList.contains('sheet-bg')) fermerFeuille(); });
}
function fermerFeuille(){ $('#sheetHost').innerHTML = ''; }

/* ---------------- AIDE ---------------- */
$('#cWaTxt').textContent = C.AGENCE_WHATSAPP_AFFICHE; $('#cTelTxt').textContent = C.AGENCE_WHATSAPP_AFFICHE; $('#cMailTxt').textContent = C.AGENCE_EMAIL;
$('#cWa').onclick = () => ouvrir(waAgence(T('Bonjour VOYAGE FACILE, ')));
$('#cTel').onclick = () => ouvrir('tel:+' + C.AGENCE_WHATSAPP);
$('#cMail').onclick = () => ouvrir('mailto:' + C.AGENCE_EMAIL);
$('#goAgence').onclick = () => montrer('agence');
$('#homeAdmin').onclick = () => montrer('agence');

/* ---------------- Monnaie des prix ---------------- */
function barreDevise(){
  return `<div class="devise-bar"><span>${T('Prix en')} <b>${esc(Devise.nom())}</b> (${esc(Devise.code())})</span><button type="button" id="chgDevise">${T('Changer')}</button></div>`;
}
$('#deviseSel').innerHTML = Devise.liste().map(d => `<option value="${d.code}"${d.code === Devise.code() ? ' selected' : ''}>${esc(d.nom)} (${d.code})</option>`).join('');
$('#deviseSel').onchange = e => { Devise.choisir(e.target.value); toast(T('Prix affichés en {d}', { d: Devise.nom() })); };
Devise.surChangement(() => { const b = document.querySelector('.devise-bar span'); if (b) b.innerHTML = `${T('Prix en')} <b>${esc(Devise.nom())}</b> (${esc(Devise.code())})`; });
$('#goIA').onclick = () => montrer('assistant');
const verWeb = window.MAJ ? T(' · mise à jour {v}', { v: MAJ.version }) : '';
$('#ver').textContent = VERSION + verWeb;
if (P().App && P().App.getInfo) P().App.getInfo().then(i => { $('#ver').textContent = i.version + verWeb; }).catch(()=>{});

/* ---------------- ACCUEIL ---------------- */
// Villes proposées sur l'accueil (photo quand elle existe, sinon carte illustrée).
const VILLES = {
  CDG:{ v:'Paris', p:'France', img:'paris' }, DSS:{ v:'Dakar', p:'Sénégal', img:'dakar' }, ABJ:{ v:'Abidjan', p:"Côte d'Ivoire", img:'abidjan' },
  CMN:{ v:'Casablanca', p:'Maroc', img:'casablanca' }, IST:{ v:'Istanbul', p:'Turquie', img:'istanbul' },
  DXB:{ v:'Dubaï', en:'Dubai', p:'Émirats arabes unis', img:'dubai' }, JED:{ v:'Djeddah', en:'Jeddah', p:'Arabie saoudite', img:'jeddah' },
  BRU:{ v:'Bruxelles', en:'Brussels', p:'Belgique', img:'bruxelles' }, CKY:{ v:'Conakry', p:'Guinée' }, BKO:{ v:'Bamako', p:'Mali' },
  LOS:{ v:'Lagos', p:'Nigeria' }, ACC:{ v:'Accra', p:'Ghana' }, LHR:{ v:'Londres', en:'London', p:'Royaume-Uni' },
  JFK:{ v:'New York', p:'États-Unis' }, YUL:{ v:'Montréal', en:'Montreal', p:'Canada' }, CAN:{ v:'Canton', en:'Guangzhou', p:'Chine' },
  FNA:{ v:'Freetown', p:'Sierra Leone' }, NBO:{ v:'Nairobi', p:'Kenya' }, ADD:{ v:'Addis-Abeba', en:'Addis Ababa', p:'Éthiopie' },
  JNB:{ v:'Johannesburg', p:'Afrique du Sud' },
};
// Destinations les plus demandées selon la région du client
const LISTES = {
  ouest_fr: ['CDG','DSS','ABJ','CMN','IST','DXB','JED','BRU','CKY','BKO'],
  ouest_en: ['LHR','DXB','JFK','ACC','LOS','IST','JED','CDG','FNA'],
  est_sud:  ['DXB','LHR','IST','JED','NBO','JNB','ADD','CDG'],
  diaspora: ['CKY','DSS','ABJ','BKO','CMN','IST','DXB','JED','LOS'],
};
const ORIGINE = window.Pays ? Pays.aeroport() : { code:'CKY', ville:'Conakry' };
function listeDestinations(){
  const c = window.Pays && Pays.code;
  let cle = 'ouest_fr';
  if (['NG','GH','SL','LR','GM'].includes(c)) cle = 'ouest_en';
  else if (['KE','ET','RW','ZA','UG','TZ','AO','MZ','ZW','ZM','BI','DJ','MG','KM','MU','SD','EG'].includes(c)) cle = 'est_sud';
  else if (c && window.Pays && !Pays.afrique) cle = 'diaspora';
  return LISTES[cle].filter(k => !ORIGINE || k !== ORIGINE.code).slice(0, 8).map(k => ({ code:k, ...VILLES[k] }));
}
const DESTINATIONS = listeDestinations();
const nomVille = d => (window.L && L.code === 'en' && d.en) || d.v;
$('#dest').innerHTML = DESTINATIONS.map((d,i) => `<button type="button" data-d="${i}">${d.img ? `<img src="img/${d.img}.jpg" alt="" loading="lazy">` : `<span class="dest-ph" aria-hidden="true">${ico('plane',40)}<i>${esc(d.code)}</i></span>`}<span class="cap"><b>${esc(nomVille(d))}</b><span>${esc(T(d.p))}</span></span></button>`).join('');
$('#dest').querySelectorAll('button').forEach(b => b.onclick = () => {
  const d = DESTINATIONS[+b.dataset.d];
  etapeVols('volsSearch'); montrer('vols');
  $('#to').value = `${nomVille(d)} (${d.code})`; $('#to').dataset.code = d.code;
  toast(T('Destination : {v}. Choisissez vos dates.', { v: nomVille(d) }));
  setTimeout(() => { try { $('#d1').focus(); $('#d1').showPicker && $('#d1').showPicker(); } catch(e){} }, 250);
});
// Ville de départ : celle du client (pays reconnu par le téléphone). Il peut la changer.
(function departParDefaut(){
  const sous = document.querySelector('#destSous');
  if (ORIGINE) {
    $('#from').value = `${ORIGINE.ville} (${ORIGINE.code})`; $('#from').dataset.code = ORIGINE.code;
    if (sous) sous.textContent = T('Vols depuis {v}', { v: ORIGINE.ville });
  } else {
    $('#from').value = ''; $('#from').dataset.code = ''; $('#from').placeholder = T('Ville ou aéroport');
    if (sous) sous.textContent = T('Partout dans le monde');
  }
})();
document.querySelectorAll('#v-accueil [data-go]').forEach(b => b.onclick = () => montrer(b.dataset.go));
document.querySelectorAll('#v-accueil [data-svc]').forEach(b => b.onclick = () => feuilleService(SERVICES.find(s => s.id === b.dataset.svc)));
$('#homeWa').onclick = () => ouvrir(waAgence(T('Bonjour VOYAGE FACILE, ')));
(function salut(){
  const h = new Date().getHours();
  const mot = T(h < 12 ? 'Bonjour' : h < 18 ? 'Bon après-midi' : 'Bonsoir');
  $('#homeHello').textContent = T("{m} ! Réservez votre billet d'avion depuis votre téléphone, sans vous déplacer.", { m: mot });
})();
// Rappel du dernier voyage du client, s'il en a un
function dernierVoyage(){
  const v = store.get('vf_voyages', [])[0];
  if (!v) { $('#homeLast').innerHTML = ''; return; }
  const n = v.statut === 'annulee' ? null : joursAvant(v.aller?.depart_heure);
  const proche = n != null && n >= 0 && n <= 14;
  $('#homeLast').innerHTML = `<button type="button" class="home-last${proche ? ' bientot' : ''}" id="homeLastBtn"><span class="ic">${ico(proche ? 'calendar-days' : 'luggage',24)}</span><span><span class="muted">${esc(proche ? texteDepart(n) : T('Votre dernière demande'))}</span><br><b>${esc(v.trajet)}</b> · ${esc(T('Réf. {r}', { r: v.reference }))}</span><span class="pill st-${esc(v.statut)}">${esc(T(LIB[v.statut] || v.statut))}</span></button>`;
  $('#homeLastBtn').onclick = () => montrer('voyages');
}
/* ---------------- Langue ---------------- */
if (window.L) {
  const lb = $('#langBtn');
  if (lb) { lb.textContent = L.autre().toUpperCase(); lb.onclick = () => L.choisir(L.autre()); }
  document.querySelectorAll('[data-langue]').forEach(b => { b.setAttribute('aria-pressed', b.dataset.langue === L.code); b.onclick = () => { if (b.dataset.langue !== L.code) L.choisir(b.dataset.langue); }; });
}

montrer('accueil');

/* Crédits des photos (Wikimedia Commons, licences libres) */
const CREDITS = [{"p": "Bannière", "a": "U.S. Department of Agriculture", "l": "Public domain", "u": "https://commons.wikimedia.org/wiki/File:A_wing_tip_of_an_airplane_(40118125441).jpg"}, {"p": "Vols", "a": "kallerna", "l": "CC BY-SA 4.0", "u": "https://commons.wikimedia.org/wiki/File:Helsinki_airport_departure_hall_2.jpg"}, {"p": "Paris", "a": "Wladyslaw (Taxiarchos228)", "l": "CC BY 3.0", "u": "https://commons.wikimedia.org/wiki/File:Paris_-_Eiffelturm_und_Marsfeld2.jpg"}, {"p": "Dakar (Gorée)", "a": "Fawaz.tairou", "l": "CC BY-SA 4.0", "u": "https://commons.wikimedia.org/wiki/File:C%C3%B4tes_de_l%27%C3%AEle_de_Gor%C3%A9e_au_S%C3%A9n%C3%A9gal_11.jpg"}, {"p": "Abidjan", "a": "Aman ADO", "l": "CC BY-SA 4.0", "u": "https://commons.wikimedia.org/wiki/File:Abidjan_en_Eburnie_33.jpg"}, {"p": "Casablanca", "a": "OussamaHamama", "l": "CC BY-SA 4.0", "u": "https://commons.wikimedia.org/wiki/File:Whispers_of_Gold_-_Hassan_II_Mosque_at_Dusk.jpg"}, {"p": "Istanbul", "a": "Moonik", "l": "CC BY-SA 3.0", "u": "https://commons.wikimedia.org/wiki/File:Exterior_of_Sultan_Ahmed_I_Mosque_in_Istanbul,_Turkey_002.jpg"}, {"p": "Dubaï", "a": "Laika ac", "l": "CC BY-SA 2.0", "u": "https://commons.wikimedia.org/wiki/File:Burj_Khalifa_(16260269606).jpg"}, {"p": "Djeddah", "a": "Tahir mq", "l": "CC BY-SA 4.0", "u": "https://commons.wikimedia.org/wiki/File:Bait_Al_Balad,_Jeddah_4.jpg"}, {"p": "Bruxelles", "a": "Trougnouf (Benoit Brummer)", "l": "CC BY 4.0", "u": "https://commons.wikimedia.org/wiki/File:Grand_Place_1-7_during_civil_twilight,_Brussels_(DSCF1982).jpg"}, {"p": "Hôtel", "a": "Basile Morin", "l": "CC BY-SA 4.0", "u": "https://commons.wikimedia.org/wiki/File:Canopy_bed_of_Amantaka_Suite_in_Amantaka_luxury_Resort_%26_Hotel_in_Luang_Prabang_Laos.jpg"}, {"p": "Visa", "a": "Jon Evans", "l": "CC BY 2.0", "u": "https://commons.wikimedia.org/wiki/File:Brazil,_Iceland,_UK,_US_passport_stamps.jpg"}, {"p": "Hajj & Omra", "a": "Adli Wahid", "l": "CC BY-SA 4.0", "u": "https://commons.wikimedia.org/wiki/File:The_Kaaba_during_Hajj_-_edited.jpg"}, {"p": "Assurance", "a": "Wouter van Beek", "l": "CC BY-SA 4.0", "u": "https://commons.wikimedia.org/wiki/File:ASC_Leiden_-_W.E.A._van_Beek_Collection_-_Thuis_in_Afrika_-_02.1_-_Baggage_handling_at_the_airport_during_a_ground_crew_strike_-_Garoua,_Cameroon_-_1999.jpg"}];
$('#creditsList').innerHTML = `<p style="margin:8px 0">${T('Photos réelles prises par des photographes et publiées sous licence libre sur Wikimedia Commons.')}</p>` +
  CREDITS.map(c => `<div style="margin:4px 0"><b>${esc(c.p)}</b> : ${esc(c.a)} · ${esc(c.l)} · <a href="#" data-u="${esc(c.u)}">source</a></div>`).join('') +
  `<p style="margin-top:8px">${T('Icônes : Lucide (licence ISC).')}</p>`;
$('#creditsList').querySelectorAll('a[data-u]').forEach(a => a.onclick = e => { e.preventDefault(); ouvrir(a.dataset.u); });
