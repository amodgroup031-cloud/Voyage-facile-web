/* =====================================================================
   VOYAGE FACILE — mises à jour automatiques (sans réinstaller l'APK)
   Au démarrage, l'application regarde s'il existe une nouvelle version
   (fichier version.json publié sur le site). Si oui, un grand écran
   s'affiche, la mise à jour se télécharge et s'installe toute seule.
   Ensuite, un petit message « Application mise à jour » s'affiche.
   ===================================================================== */
const VERSION_WEB = '2026.11.28.5';
// Une seule ligne, gardée dans version.json (les anciennes versions de l'application l'affichent encore une dernière fois).
// L'écran de mise à jour ne montre plus de liste de nouveautés.
const NOTES_MAJ = [
  'Hôtels du monde entier, application adaptée à tous les pays, Mes discussions',
];
const NOTES_MAJ_EN = [
  'Hotels worldwide, app adapted to every country, My chats',
];
(function(){
  const URL_MAJ = 'https://amodgroup031-cloud.github.io/Voyage-facile-web/app/version.json';
  const PL = () => (window.Capacitor && window.Capacitor.Plugins) || {};
  const CU = () => PL().CapacitorUpdater;
  // À appeler tout de suite : confirme que cette version démarre bien (sinon retour automatique à l'ancienne).
  if (CU()) CU().notifyAppReady().catch(() => {});

  const lire = k => { try { return localStorage.getItem(k); } catch(e){ return null; } };
  const ecrire = (k, v) => { try { localStorage.setItem(k, v); } catch(e){} };
  const plusRecente = (a, b) => {
    const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
    for (let i = 0; i < Math.max(x.length, y.length); i++) { const d = (x[i] || 0) - (y[i] || 0); if (d) return d > 0; }
    return false;
  };
  const e = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));

  // Grand écran (au-dessus de toute l'application)
  function ecran(contenu){
    let el = document.getElementById('majEcran');
    if (!el) { el = document.createElement('div'); el.id = 'majEcran'; el.setAttribute('role', 'dialog'); el.setAttribute('aria-modal', 'true'); document.body.appendChild(el); }
    el.innerHTML = `<div class="maj-in">
      <svg class="maj-logo" viewBox="14 0 112 112" aria-hidden="true"><path d="M56 100 C56 100 22 70 22 45 C22 26 37 11 56 11 C75 11 90 26 90 45 C90 70 56 100 56 100 Z" fill="#ffffff"/><path d="M40 46 L52 58 L73 35" fill="none" stroke="#0b2545" stroke-width="9.5" stroke-linecap="round" stroke-linejoin="round"/><path transform="translate(96 18) rotate(-40) scale(1.25)" d="M17 0 C17 -1.5 15.6 -2.5 13 -2.5 L4.6 -2.5 L-4.8 -15.5 L-8.8 -15.5 L-3.4 -2.5 L-10.4 -2.5 L-13.8 -7.6 L-16.4 -7.6 L-14.4 -2 L-15.4 0 L-14.4 2 L-16.4 7.6 L-13.8 7.6 L-10.4 2.5 L-3.4 2.5 L-8.8 15.5 L-4.8 15.5 L4.6 2.5 L13 2.5 C15.6 2.5 17 1.5 17 0 Z" fill="#f28c28"/></svg>
      ${contenu}</div>`;
    el.hidden = false;
    return el;
  }
  const fermer = () => { const el = document.getElementById('majEcran'); if (el) el.hidden = true; };
  const T = (s, v) => window.L ? L.t(s, v) : s;

  // Petit message discret en bas de l'écran, qui s'efface tout seul.
  function petitMessage(texte){
    const m = document.createElement('div'); m.className = 'maj-toast'; m.setAttribute('role', 'status'); m.textContent = texte;
    document.body.appendChild(m);
    requestAnimationFrame(() => m.classList.add('on'));
    setTimeout(() => { m.classList.remove('on'); setTimeout(() => m.remove(), 400); }, 3200);
  }

  // 1) Après une mise à jour : un simple petit message « Application mise à jour » (une seule fois).
  function nouveautes(){
    if (lire('vf-maj-vue') === VERSION_WEB) return false;
    const premiere = !lire('vf-maj-vue') && !lire('vf_voyages') && !lire('vf_moi');
    ecrire('vf-maj-vue', VERSION_WEB);
    if (premiere) return false;            // tout premier lancement : pas de message
    setTimeout(() => petitMessage(T('Application mise à jour')), 600);
    return true;
  }

  async function versionNative(){
    try { const i = await PL().App.getInfo(); return Number(i.build) || 0; } catch(err){ return 0; }
  }

  // 2) Vérifier s'il existe une nouvelle version.
  let enCours = false, derniere = 0;
  async function verifier(){
    if (!CU() || enCours) return;
    enCours = true; derniere = Date.now();
    try {
      let info;
      try { const r = await fetch(URL_MAJ + '?t=' + Date.now(), { cache: 'no-store' }); if (!r.ok) return; info = await r.json(); }
      catch(err){ return; }                // hors ligne : on réessaiera plus tard
      const natif = await versionNative();
      if (info.native_min && natif && natif < info.native_min && info.apk) { proposerApk(info); return; }
      if (!info.web || !info.zip || !info.checksum || !plusRecente(info.web, VERSION_WEB)) return;
      const el = ecran(`<h2>Mise à jour disponible</h2><p class="maj-sous">Installation en cours, gardez l'application ouverte.</p>
        <div class="maj-barre"><i id="majBarre" style="width:3%"></i></div><p class="maj-sous" id="majPct">Téléchargement…</p>`);
      let ecoute = null;
      try { ecoute = await CU().addListener('download', s => { const p = Math.max(3, Math.min(100, Number(s.percent) || 0)); const b = el.querySelector('#majBarre'); if (b) b.style.width = p + '%'; const t = el.querySelector('#majPct'); if (t) t.textContent = T('Téléchargement… {p} %', { p: Math.round(p) }); }); } catch(err){}
      try {
        const bundle = await CU().download({ url: info.zip, version: info.web, checksum: info.checksum });
        el.querySelector('#majPct').textContent = 'Installation…';
        await CU().set({ id: bundle.id });        // l'application redémarre sur la nouvelle version
      } catch(err){
        if (ecoute) try { ecoute.remove(); } catch(x){}
        const el2 = ecran(`<h2>Mise à jour reportée</h2><p class="maj-sous">Le téléchargement n'a pas abouti (connexion faible ?). Nous réessaierons automatiquement.</p>
          <button class="btn btn-or w100" type="button" id="majOk">Continuer</button>`);
        el2.querySelector('#majOk').onclick = fermer;
      }
    } finally { enCours = false; }
  }

  // Rare : nouvelle version de l'application elle-même (nouvelle fonction du téléphone).
  function proposerApk(info){
    const el = ecran(`<h2>Mise à jour disponible</h2><p class="maj-sous">${e(T("Cette mise à jour demande d'installer la nouvelle application ({v}). Vos voyages restent enregistrés.", { v: info.apk_version || '' }))}</p>
      <button class="btn btn-or w100" type="button" id="majApk">Télécharger la nouvelle version</button>
      <button class="btn btn-glass w100" type="button" id="majPlusTard" style="margin-top:8px">Plus tard</button>`);
    el.querySelector('#majApk').onclick = () => {
      const AL = PL().AppLauncher;
      if (AL) AL.openUrl({ url: info.apk }).catch(() => { window.location.href = info.apk; }); else window.open(info.apk, '_blank');
    };
    el.querySelector('#majPlusTard').onclick = fermer;
  }

  window.MAJ = { version: VERSION_WEB, verifier, versionNative };
  const demarrer = () => {
    nouveautes();
    verifier();
    try { PL().App.addListener('resume', () => { if (Date.now() - derniere > 30 * 60e3) verifier(); }); } catch(err){}
  };
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', demarrer); else demarrer();
})();
